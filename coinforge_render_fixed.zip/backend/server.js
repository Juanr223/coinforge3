const express = require("express");
const cors = require("cors");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.get("/api/status", (req, res) => res.send("Backend funcionando correctamente"));

app.listen(PORT, () => console.log("Servidor backend en puerto", PORT));